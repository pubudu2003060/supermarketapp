import React from 'react'
import { BrowserRouter, Router, Routes } from 'react-router-dom'
import Home from './screens/Home.screen'
import Layout from './components/Layout'
import NoElement from './components/NoElement'

const App = () => {
  return (
    <>
     <BrowserRouter>
      <Routes>
        <Rout path="/user" element={<Layout/>} >
          <Rout index element={<Home/>}/>
          <Rout path="*" element={<NoElement/>}/>
        </Rout>
      </Routes>
    </BrowserRouter>
    
    </>
   
  )
}

export default App
