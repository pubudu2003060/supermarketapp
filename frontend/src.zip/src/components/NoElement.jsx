import React from 'react'

const NoElement = () => {
  return (
    <div>
      NoElement
    </div>
  )
}

export default NoElement
